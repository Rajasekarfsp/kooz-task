import ServiceImg1 from "../img/service-img1.jpg";
import ServiceImg2 from "../img/service-img2.jpg";
import ServiceImg3 from "../img/service-img3.jpg";
import ServiceImg4 from "../img/service-img4.jpg";
import ServiceImg5 from "../img/service-img5.jpg";


const servicedata = [
  {
    image: ServiceImg1,
    title: "Bitcoin Exchange",
    text: "We help business improve"
  },
  {
    image: ServiceImg2,
    title: "Bitcoin Transaction",
    text: "We help business improve"
  },
  {
    image: ServiceImg3,
    title: "Bitcoin Investment",
    text: "We help business improve"
  },
  {
    image: ServiceImg4,
    title: "Bitcoin Transaction",
    text: "We help business improve"
  },
  {
    image: ServiceImg5,
    title: "Bitcoin Transaction",
    text: "We help business improve"
  }
];

export default servicedata;
