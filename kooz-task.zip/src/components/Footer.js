import React from "react";
import Container from "react-bootstrap/Container";
import Row from "react-bootstrap/Row";
import Col from "react-bootstrap/Col";

export default function Footer() {
  return (
    <footer className="clsfooter bg-dark pt-4 pb-4">
      <Container>
        <Row className="align-items-center">
          <Col md={6} className="mr-auto">
            <p className="mb-0">
              Copyright ©2018 mywebsite. All Rights Reserved
            </p>
          </Col>
          <Col md={6} className="text-right">
            <div className="clsfooter-menus">
              <ul className="d-flex justify-content-center justify-content-md-end mb-0 mt-sm-3">
                <li>
                  <a href="#">FAQ</a>
                </li>
                <li>
                  <a href="#">Privacy Policy</a>
                </li>
                <li>
                  <a href="#">Support</a>
                </li>
                <li>
                  <a href="#">Contact</a>
                </li>
              </ul>
            </div>
          </Col>
        </Row>
      </Container>
    </footer>
  );
}
