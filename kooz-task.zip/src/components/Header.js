import Container from "react-bootstrap/Container";
import Nav from "react-bootstrap/Nav";
import Navbar from "react-bootstrap/Navbar";
import NavDropdown from "react-bootstrap/NavDropdown";
import logo from "../img/logo.svg";
import Button from "react-bootstrap/Button";

export default function CollapsibleExample() {
  return (
    <Navbar
      sticky="top"
      collapseOnSelect
      expand="lg"
      bg="dark"
      data-bs-theme="dark"
    >
      <Container fluid>
        <Navbar.Brand href="#">
          <img src={logo} alt="KoinBx" className="" />
        </Navbar.Brand>
        <Navbar.Toggle aria-controls="responsive-navbar-nav" />
        <Navbar.Collapse id="responsive-navbar-nav">
          <Nav className="me-auto">
            <Nav.Link href="#">Markets</Nav.Link>
            <Nav.Link href="#">Fees</Nav.Link>
            <NavDropdown title="Dropdown" id="collasible-nav-dropdown">
              <NavDropdown.Item href="#">Trade</NavDropdown.Item>
              <NavDropdown.Item href="#">Another action</NavDropdown.Item>
              <NavDropdown.Item href="#">Something</NavDropdown.Item>
            </NavDropdown>
            <Nav.Link href="#">List Your Crypto</Nav.Link>
          </Nav>
          <Nav className="align-items-lg-center">
            <Nav.Link href="#">Login</Nav.Link>
            <Nav.Link eventKey={2} href="#">
              <Button variant="warning" className="clsgreen-btn">
                Signup
              </Button>
            </Nav.Link>
          </Nav>
        </Navbar.Collapse>
      </Container>
    </Navbar>
  );
}
