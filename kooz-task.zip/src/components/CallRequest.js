import React from "react";
import Row from "react-bootstrap/Row";
import Col from "react-bootstrap/Col";
import Container from "react-bootstrap/Container";
import Button from "react-bootstrap/Button";
import Form from "react-bootstrap/Form";
import PersonImg from "../img/person.png";

export default function CallRequest() {
  return (
    <section className="clscall-request-section pt-4">
      <Container>
        <Row className="align-items-center">
          <Col md={7}>
            <div className="clscall-form-block">
              <h3 className="mb-3">Request a Call Back</h3>
              <p className="mb-4 mb-lg-3">
                Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quidem
                fugit sequi soluta sit dolor blanditiis reiciendis deleniti
                cumque doloremque ratione.
              </p>
              <Form>
                <Row>
                  <Col sm={6}>
                    <Form.Group className="mb-3">
                      <Form.Control type="text" placeholder="Enter Name" />
                    </Form.Group>
                  </Col>
                  <Col sm={6}>
                    <Form.Group className="mb-3">
                      <Form.Control type="email" placeholder="Enter Email" />
                    </Form.Group>
                  </Col>
                  <Col sm={6}>
                  <Form.Group className="mb-3">
                      <Form.Control type="text" placeholder="Enter Address" />
                    </Form.Group>
                  </Col>
                  <Col sm={6}>
                    <Form.Group className="mb-3" controlId="formBasicEmail">
                      <Button className="clsgreen-btn" type="submit">
                        Submit
                      </Button>
                    </Form.Group>
                  </Col>
                </Row>
              </Form>
            </div>
          </Col>
          <Col md={5}>
            <figure className="mb-0 clscall-person-img">
              <img src={PersonImg} alt="Call" className="img-fluid" />
            </figure>
          </Col>
        </Row>
      </Container>
    </section>
  );
}
