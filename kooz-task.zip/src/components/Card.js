import React from 'react'
import Card from "react-bootstrap/Card";
import Col from "react-bootstrap/Col";
import Row from "react-bootstrap/Row";
import Button from 'react-bootstrap/Button';
import investmentImage1 from "../img/current-investment1.jpg";
import investmentImage2 from "../img/current-investment2.jpg";
import investmentImage3 from "../img/current-investment3.jpg";

const investmentData = [
    {
      title: "Bitcoin Transaction",
      text: "Lorem ipsum dolor sit amet, consectetur adipisicing elit. Molestias non nulla placeat, odio, qui dicta alias.",
      image: investmentImage1,
    },
    {
      title: "Bitcoin Investment",
      text: "Lorem ipsum dolor sit amet, consectetur adipisicing elit. Molestias non nulla placeat, odio, qui dicta alias.",
      image: investmentImage2,
    },
    {
      title: "Bitcoin Exchange",
      text: "Lorem ipsum dolor sit amet, consectetur adipisicing elit. Molestias non nulla placeat, odio, qui dicta alias.",
      image: investmentImage3,
    },
  ];
export default function InvestCard() {
  return (
    <>
        <Row xs={1} md={3} className="g-4 mt-4">
          {investmentData.map((data, index) => (
            <Col key={index}>
              <Card>
                <Card.Img
                  variant="top"
                  src={data.image}
                  className="img-fluid"
                />
                <Card.Body className="text-center pt-4 pb-5">
                  <Card.Title>{data.title}</Card.Title>
                  <Card.Text className="mt-3">{data.text}</Card.Text>
                  <Button className="clsgreen-btn mt-2">Read More</Button>
                </Card.Body>
              </Card>
            </Col>
          ))}
        </Row>
    </>
  )
}
