import React from 'react';
import Banner from '../Banner';
import CurrentInvestment from '../CurrentInvestment';
import BuySell from '../BuySell';
import OurServices from '../OurServices';
import CallRequest from '../CallRequest';


export default function Home() {
  return (
    <>
    <Banner/>
    <CurrentInvestment/>
    <BuySell/>
    <OurServices/>
    <CallRequest/>
    </>
  )
}
