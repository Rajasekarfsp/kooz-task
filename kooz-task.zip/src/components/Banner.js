import React, { Component } from "react";
import Slider from "react-slick";
import "../../node_modules/slick-carousel/slick/slick.css";
import "../../node_modules/slick-carousel/slick/slick-theme.css";
import bannerData from "./BannerData";

export default class SimpleSlider extends Component {
  render() {
    const settings = {
      dots: true,
      infinite: true,
      speed: 500,
      slidesToShow: 1,
      slidesToScroll: 1,
    };

    return (
      <section className="clshero-banner-section">
        <Slider {...settings}>
          {bannerData.map((banner, index) => (
            <div key={index}>
              <figure>
                <img src={banner.image} alt="KoinBx" className="img-fluid" />
                <div className="clsbanner-content">
                  <h1>
                    {banner.titleParts.map((part, partIndex) =>
                      React.isValidElement(part) ? (
                        <span key={partIndex}>{part}</span>
                      ) : (
                        part
                      )
                    )}
                  </h1>
                  <div className="d-flex clsappstore-btn-block mt-3 mt-sm-5">
                    <a href="#">
                      <img
                        src={banner.appStoreImage}
                        alt="KoinBx"
                        className="img-fluid"
                      />
                    </a>
                    <a href="#">
                      <img
                        src={banner.playStoreImage}
                        alt="KoinBx"
                        className="img-fluid"
                      />
                    </a>
                  </div>
                </div>
              </figure>
            </div>
          ))}
        </Slider>
      </section>
    );
  }
}
