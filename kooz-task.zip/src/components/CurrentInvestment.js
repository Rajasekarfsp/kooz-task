import React from "react";
import InvestCard from "./Card";


export default function CurrentInvestment() {
  return (
    <section className="clscurrent-investment-section">
      <div className="container">
        <h2 className="text-center text-uppercase mb-4">
          Need to take care of your Currency Investments
        </h2>
        <p className="text-center">
          Lorem ipsum dolor sit amet, consectetur adipisicing elit. Rem autem
          voluptatem obcaecati!<br/> ipsum dolor sit Rem autem voluptatem obcaecati
        </p>
        <InvestCard/>
      </div>
    </section>
  );
}
