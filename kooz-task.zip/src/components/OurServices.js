import React from "react";
import Slider from "react-slick";
import servicedata from "./ServiceData";
import Button from "react-bootstrap/Button";

export default function AutoPlay() {
  const settings = {
    dots: false,
    infinite: true,
    slidesToShow: 4,
    slidesToScroll: 1,
    autoplay: true,
    autoplaySpeed: 2000,
    pauseOnHover: true,
    responsive: [
      {
        breakpoint: 1024,
        settings: {
          slidesToShow: 3,
          slidesToScroll: 1,
          infinite: true,
        }
      },
      {
        breakpoint: 600,
        settings: {
          slidesToShow: 2,
          slidesToScroll: 1,
        }
      },

    ]
  };

  return (
    <section className="clsour-service-section">
        <h2 className="text-center text-uppercase mb-4">
        Our Services
        </h2>
        <p className="text-center">
          Lorem ipsum dolor sit amet, consectetur adipisicing elit. Rem autem
          voluptatem obcaecati!<br/> ipsum dolor sit Rem autem voluptatem obcaecati
        </p>
      <Slider {...settings} className="clsservice-slider mt-5">
        {servicedata.map((item, index) => (
          <div key={index} className="clsservice-slider-box">
            <figure className="mb-0">
              <img src={item.image} alt="Service" className="img-fluid" />
            </figure>
            <div className="clsservice-slider-content text-center">
            <div className="clsservice-slider-content-inner">
              <h3>{item.title}</h3>
              <p>{item.text}</p>
              <Button className="clsgreen-btn mt-2">View Details</Button>
              </div>
            </div>
          </div>
        ))}
      </Slider>
    </section>
  );
}
