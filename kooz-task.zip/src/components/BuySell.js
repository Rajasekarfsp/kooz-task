import React, { Component } from "react";
import Container from "react-bootstrap/Container";
import Row from "react-bootstrap/Row";
import Col from "react-bootstrap/Col";
import Button from "react-bootstrap/Button";
import BuyImg1 from "../img/buy-img1.jpg";
import BuyImg2 from "../img/buy-img2.jpg";
import BuyImg3 from "../img/buy-img3.jpg";
import BuyImg4 from "../img/buy-img4.jpg";

class BuySell extends Component {
  render() {
    return (
      <section className="clsbuy-sell-section pt-5 pb-5 mt-5 mb-3">
        <Container>
          <Row className="align-items-center">
            <Col md={6}>
              <div className="clsbuy-sell-content">
                <h3 className="mb-4">
                  Buy, sell and Exchange all you need to know about bitcoin
                </h3>
                <p className="mb-4">
                  Lorem ipsum dolor sit amet, consectetur adipisicing elit.
                  Aliquam, odioserunt provident maiores consectetur adipisicing
                  elit. Aliquam odio dese runtesseu provident maiores libero porro
                  dolorem est. Velit necessitatibus fugiat error incidunt
                  excepturi doloribus officia aspernatur quod libero Velit
                  necessitatibus fugiat error incidunt excepturi doloribus officia
                </p>
                <Button className="clsgreen-btn mt-2">Read More</Button>
                <Button className="clsblack-btn mt-2">Read More</Button>
              </div>
            </Col>
            <Col md={6}>
              <div className="clsbuy-sell-img-block">
                <Row className="mb-2">
                  <Col sm={5}>
                    <figure>
                      <img src={BuyImg1} alt="Buy" className="img-fluid" />
                    </figure>
                  </Col>
                  <Col sm={7}>
                    <figure>
                      <img src={BuyImg2} alt="Buy" className="img-fluid" />
                    </figure>
                  </Col>
                </Row>
                <Row>
                  <Col sm={7}>
                    <figure>
                      <img src={BuyImg3} alt="Buy" className="img-fluid" />
                    </figure>
                  </Col>
                  <Col sm={5}>
                    <figure>
                      <img src={BuyImg4} alt="Buy" className="img-fluid" />
                    </figure>
                  </Col>
                </Row>
              </div>
            </Col>
          </Row>
        </Container>
      </section>
    );
  }
}

export default BuySell;
