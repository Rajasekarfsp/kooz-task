import banner1 from "../img/banner-img1.jpg";
import banner2 from "../img/banner-img2.jpg";
import appStore from "../img/app-store.png";
import playStore from "../img/play-store.png";
const bannerData = [
  {
    image: banner1,
    titleParts: [
      "Take the ",
      <span key="world">world's</span>,
      " best ",
      <span key="Cryptocurrency">Cryptocurrency</span>,
      " Site.",
    ],
    appStoreImage: appStore,
    playStoreImage: playStore,
  },
  {
    image: banner2,
    titleParts: [
      "We help you ",
      <span key="world">business</span>,
      " to grow and expand.",
    ],
    appStoreImage: appStore,
    playStoreImage: playStore,
  },
];

export default bannerData;
